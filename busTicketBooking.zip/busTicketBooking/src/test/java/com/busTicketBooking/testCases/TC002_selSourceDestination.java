package com.busTicketBooking.testCases;

import java.io.IOException;

import org.testng.annotations.Test;

import com.busTicketBooking.pageObjects.HomePage;

public class TC002_selSourceDestination extends BaseClass  {
	@Test
	public void menuPage() throws IOException {
	HomePage hp = new HomePage(driver);
	hp.clickFrom();
	hp.clickSource();
	logger.info("Entered entered from/source");

}
}
