package com.busTicketBooking.testCases;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.busTicketBooking.pageObjects.HomePage;

public class TC_001_launchUrl extends BaseClass {

	@Test
	public void menuPage() throws IOException {

		logger.info("URL is opened");
		
		/*
		 * if(driver.getTitle().equals("main")) { Assert.assertTrue(true);
		 * logger.info("URL launch test passed"); } else {
		 * captureScreen(driver,"urlLaunch"); Assert.assertTrue(false);
		 * logger.info("URL launch test failed"); }
		 */

		/*
		 * if(driver.getTitle().equals("BusOnlineTicket.com")) {
		 * Assert.assertTrue(true); logger.info("URL launch test passed"); } else {
		 * captureScreen(driver,"URL Launch"); Assert.assertTrue(false);
		 * logger.info("URL launch test failed"); }
		 */

	}

}
